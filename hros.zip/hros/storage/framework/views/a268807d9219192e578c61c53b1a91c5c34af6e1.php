

<?php $__env->startSection('content'); ?>

<div class="m-3">
<div class="container px-4">
  <div class="row gx-5">
    <div class="col">
     <div style="width: 245px; height: 202px; left: 369px; top: 372px; background: linear-gradient(124.52deg, #FBFFDF -65.57%, rgba(251, 255, 223, 0) 117.14%); filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25)); border-radius: 30px;">
        <div style="width: 176px; height: 176px; left: 403px; top: 385px; background: url(assets/verifikasi.png);"></div>
        <div style="width: 272px; height: 38px; left: 361px; top: 585px; font-family: 'Roboto'; font-style: normal; font-weight: 800; font-size: 32.5549px; line-height: 38px; color: rgba(6, 40, 61, 0.79);"> Verifikasi Fasilitas </div>
     </div>
    </div>
    <div class="col">
      <div style="width: 245px; height: 202px; left: 369px; top: 372px; background: linear-gradient(124.52deg, #FBFFDF -65.57%, rgba(251, 255, 223, 0) 117.14%); filter: drop-shadow(0px 4px 4px rgba(0, 0, 0, 0.25)); border-radius: 30px;">
        <div style="width: 131px; height: 128px; left: 869px; top: 409px; background: url(assets/masterdata.png);"></div>
        <div style="width: 272px; height: 38px; left: 361px; top: 585px; font-family: 'Roboto'; font-style: normal; font-weight: 800; font-size: 32.5549px; line-height: 38px; color: rgba(6, 40, 61, 0.79);"> Master Data </div>
        </div>
    </div>
  </div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PERURI\hros\resources\views/dashboard.blade.php ENDPATH**/ ?>