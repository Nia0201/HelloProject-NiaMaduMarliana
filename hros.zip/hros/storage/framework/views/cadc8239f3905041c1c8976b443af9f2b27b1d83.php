<!DOCTYPE html>
<html>
    <head>
         <!-- Bootstrap CDN -->
         <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

        <style>
            body {
                background: linear-gradient(242.18deg, #4DADFF 14.98%, #4DADFF 14.99%, rgba(97, 221, 254, 0) 110.4%);
            }
        </style>

    </head>

    <body>
    <nav class="navbar navbar-expand-lg bg-linear-gradient">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Versity</a>
      <div class="navbar-nav">
      <ul class="nav justify-content-end">
      <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Dasboard</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Profile</a>
  </li>
      </div>
    </div>
  </div>
</nav>

        <?php echo $__env->yieldContent('content'); ?>
    </body>
<?php /**PATH D:\PERURI\hros\resources\views/layout/master.blade.php ENDPATH**/ ?>